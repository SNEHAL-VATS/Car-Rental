from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UserRegisterForm
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from .models import Booking, Car  
from django import forms
from django.views.generic import ListView,CreateView
from datetime import date

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        print('posting')
        if form.is_valid():
            print('valid')
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created! You can now login')
            return redirect('login')
    else:
        print('not posted')
        form = UserRegisterForm()
    print('fail')
    return render(request, 'logsign/register.html', {'form': form})


@login_required
def rent(request):
    return render(request,'logsign/rent.html')

def home(request):
    return render(request,'logsign/home.html')

def about(request):
    return render(request,'logsign/about.html')


@login_required
def listings(request):
    context = {
        'bookings' : Booking.objects.filter(user=request.user)
    }
    return render(request,'logsign/rentlist.html',context)


'''
class RentListView(ListView):
    model = Booking
    template_name = 'logsign/rentlist.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'bookings'
    ordering = ['-date_booked']
'''

class RentCreateView(LoginRequiredMixin, CreateView):
    model = Booking
    fields = ['car','price','location','start_date','end_date']

    #template_name = 'logsign/rent.html'
    def form_valid(self, form):
        form.instance.user = self.request.user
        c1 = form.instance.car
        print(c1)
        
        #form.instance.price = self.myprice
        return super().form_valid(form)
