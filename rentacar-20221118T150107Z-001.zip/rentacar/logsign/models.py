from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Car(models.Model):
    car = models.CharField(max_length=100)
    cost = models.IntegerField()

    def total(self,ndays):
        t = ndays*(self.cost)
        return t 




class Booking(models.Model):
    booking_id = models.AutoField(primary_key=True)
    location = models.CharField(max_length=100)
    car = models.CharField(max_length=100)
    price = models.IntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date_booked = models.DateTimeField(default=timezone.now)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()


   

    def get_absolute_url(self):
        return reverse('rentlist')
    