from django.urls import path
from django.conf.urls import url
from.views import RentCreateView
from . import views

urlpatterns = [
    url('rent/new/', RentCreateView.as_view(), name='rent'),
    url('list/',views.listings, name='rentlist'),
    url('register/',views.register,name='register'),
    url('about/',views.about,name='about'),
    url('',views.home,name='home'),
]

