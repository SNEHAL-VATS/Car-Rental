from django.apps import AppConfig


class LogsignConfig(AppConfig):
    name = 'logsign'
